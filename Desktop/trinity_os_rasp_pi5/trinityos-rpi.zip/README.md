# TrinityOS-RPi

🌍 A lightweight, modular Linux distribution built for Raspberry Pi 5+.

## Highlights
- Optimized for Pi hardware
- Modular voice and shell interfaces
- Clean systemd boot services
- Prepped for Pi Store distribution

## Directory Structure
- `boot/` — Bootloader configs
- `rootfs/` — Core file system
- `opt/trinity/modules/` — Modular components (voice, shell)
- `etc/systemd/` — Service autoload

## License
MIT — For freedom, learning, and love.
